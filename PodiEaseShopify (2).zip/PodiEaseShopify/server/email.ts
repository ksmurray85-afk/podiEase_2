import { Resend } from 'resend';

let connectionSettings: any;

async function getCredentials() {
  const hostname = process.env.REPLIT_CONNECTORS_HOSTNAME;
  const xReplitToken = process.env.REPL_IDENTITY 
    ? 'repl ' + process.env.REPL_IDENTITY 
    : process.env.WEB_REPL_RENEWAL 
    ? 'depl ' + process.env.WEB_REPL_RENEWAL 
    : null;

  if (!xReplitToken) {
    throw new Error('X_REPLIT_TOKEN not found for repl/depl');
  }

  connectionSettings = await fetch(
    'https://' + hostname + '/api/v2/connection?include_secrets=true&connector_names=resend',
    {
      headers: {
        'Accept': 'application/json',
        'X_REPLIT_TOKEN': xReplitToken
      }
    }
  ).then(res => res.json()).then(data => data.items?.[0]);

  if (!connectionSettings || (!connectionSettings.settings.api_key)) {
    throw new Error('Resend not connected');
  }
  return {
    apiKey: connectionSettings.settings.api_key, 
    fromEmail: connectionSettings.settings.from_email
  };
}

// WARNING: Never cache this client.
// Access tokens expire, so a new client must be created each time.
async function getUncachableResendClient() {
  const credentials = await getCredentials();
  return {
    client: new Resend(credentials.apiKey),
    fromEmail: connectionSettings.settings.from_email
  };
}

interface QuizResultEmailData {
  firstName: string;
  email: string;
  programTitle: string;
  programDescription: string;
  dayPlan: Array<{
    day: number;
    title: string;
    exercises: string[];
    tips: string[];
  }>;
}

export async function sendQuizResultEmail(data: QuizResultEmailData) {
  try {
    const { client, fromEmail } = await getUncachableResendClient();
    
    const dayPlanHtml = data.dayPlan.map((day) => `
      <div style="margin-bottom: 24px; padding: 20px; background-color: #f9f9f9; border-left: 4px solid #593f32;">
        <h3 style="color: #593f32; margin: 0 0 12px 0;">Day ${day.day}: ${day.title}</h3>
        
        <div style="margin-bottom: 12px;">
          <h4 style="color: #2f2724; font-size: 14px; margin: 0 0 8px 0;">Exercises:</h4>
          <ul style="margin: 0; padding-left: 20px;">
            ${day.exercises.map(ex => `<li style="margin-bottom: 4px; color: #2f2724;">${ex}</li>`).join('')}
          </ul>
        </div>
        
        <div>
          <h4 style="color: #2f2724; font-size: 14px; margin: 0 0 8px 0;">Tips:</h4>
          <ul style="margin: 0; padding-left: 20px;">
            ${day.tips.map(tip => `<li style="margin-bottom: 4px; color: #2f2724;">${tip}</li>`).join('')}
          </ul>
        </div>
      </div>
    `).join('');

    const html = `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
        </head>
        <body style="font-family: 'Open Sans', Arial, sans-serif; line-height: 1.6; color: #2f2724; margin: 0; padding: 0; background-color: #ffffff;">
          <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
            
            <!-- Header -->
            <div style="text-align: center; margin-bottom: 32px; padding: 24px; background-color: #593f32;">
              <h1 style="color: #ffffff; margin: 0; font-size: 28px;">Your Personalized Foot Health Plan</h1>
              <p style="color: #eee9e3; margin: 8px 0 0 0; font-size: 16px;">Where science meets your sole</p>
            </div>

            <!-- Greeting -->
            <div style="margin-bottom: 24px;">
              <p style="font-size: 18px; color: #2f2724; margin: 0;">Hi ${data.firstName},</p>
              <p style="color: #2f2724; margin: 12px 0 0 0;">Thank you for completing our Foot Health Quiz! Based on your responses, we've created a personalized 7-day program designed specifically for you.</p>
            </div>

            <!-- Program Overview -->
            <div style="margin-bottom: 32px; padding: 20px; background-color: #eee9e3; border-radius: 8px;">
              <h2 style="color: #593f32; margin: 0 0 12px 0; font-size: 22px;">${data.programTitle}</h2>
              <p style="color: #2f2724; margin: 0;">${data.programDescription}</p>
            </div>

            <!-- 7-Day Plan -->
            <div style="margin-bottom: 32px;">
              <h2 style="color: #593f32; margin: 0 0 20px 0; font-size: 22px;">Your 7-Day Journey</h2>
              ${dayPlanHtml}
            </div>

            <!-- CTA -->
            <div style="text-align: center; margin-bottom: 32px; padding: 24px; background-color: #eee9e3; border-radius: 8px;">
              <p style="color: #2f2724; margin: 0 0 16px 0; font-size: 16px;">Ready to start your journey to pain-free movement?</p>
              <a href="https://${process.env.REPLIT_DEV_DOMAIN || 'podiease.com'}/shop" style="display: inline-block; background-color: #593f32; color: #ffffff; padding: 12px 32px; text-decoration: none; border-radius: 4px; font-weight: 600;">Shop Recommended Products</a>
            </div>

            <!-- Footer -->
            <div style="text-align: center; padding-top: 24px; border-top: 1px solid #d3b495;">
              <p style="color: #7f6355; font-size: 14px; margin: 0 0 8px 0;">Expert care, delivered to your door</p>
              <p style="color: #7f6355; font-size: 12px; margin: 0;">
                PodiEase - Australia's trusted podiatrist-led store for plantar fasciitis relief
              </p>
            </div>

          </div>
        </body>
      </html>
    `;

    const result = await client.emails.send({
      from: fromEmail,
      to: data.email,
      subject: `Your Personalized ${data.programTitle} is Ready! 🦶`,
      html,
    });

    console.log('Quiz result email sent successfully:', result);
    return result;
  } catch (error) {
    console.error('Error sending quiz result email:', error);
    throw error;
  }
}

interface WelcomeEmailData {
  email: string;
  firstName?: string;
}

export async function sendWelcomeEmail(data: WelcomeEmailData) {
  try {
    const { client, fromEmail } = await getUncachableResendClient();
    
    const greeting = data.firstName ? `Hi ${data.firstName}` : 'Hello';

    const html = `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
        </head>
        <body style="font-family: 'Open Sans', Arial, sans-serif; line-height: 1.6; color: #2f2724; margin: 0; padding: 0; background-color: #ffffff;">
          <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
            
            <!-- Header -->
            <div style="text-align: center; margin-bottom: 32px; padding: 24px; background-color: #593f32;">
              <h1 style="color: #ffffff; margin: 0; font-size: 28px;">Welcome to PodiEase!</h1>
              <p style="color: #eee9e3; margin: 8px 0 0 0; font-size: 16px;">Where science meets your sole</p>
            </div>

            <!-- Greeting -->
            <div style="margin-bottom: 24px;">
              <p style="font-size: 18px; color: #2f2724; margin: 0 0 16px 0;">${greeting},</p>
              <p style="color: #2f2724; margin: 0 0 12px 0;">Thank you for subscribing to the PodiEase newsletter! We're thrilled to have you join our community of people taking control of their foot health.</p>
              <p style="color: #2f2724; margin: 0;">As a subscriber, you'll receive:</p>
            </div>

            <!-- Benefits -->
            <div style="margin-bottom: 32px;">
              <div style="margin-bottom: 16px; padding: 16px; background-color: #f9f9f9; border-left: 4px solid #593f32;">
                <h3 style="color: #593f32; margin: 0 0 8px 0; font-size: 16px;">📚 Expert Care Tips</h3>
                <p style="color: #2f2724; margin: 0; font-size: 14px;">Evidence-based advice from our podiatry team to help you manage and prevent foot pain.</p>
              </div>
              
              <div style="margin-bottom: 16px; padding: 16px; background-color: #f9f9f9; border-left: 4px solid #593f32;">
                <h3 style="color: #593f32; margin: 0 0 8px 0; font-size: 16px;">🎁 Exclusive Offers</h3>
                <p style="color: #2f2724; margin: 0; font-size: 14px;">Be the first to know about special promotions and new product launches.</p>
              </div>
              
              <div style="margin-bottom: 16px; padding: 16px; background-color: #f9f9f9; border-left: 4px solid #593f32;">
                <h3 style="color: #593f32; margin: 0 0 8px 0; font-size: 16px;">💡 Educational Resources</h3>
                <p style="color: #2f2724; margin: 0; font-size: 14px;">Free guides, exercise videos, and recovery protocols to support your journey.</p>
              </div>
            </div>

            <!-- CTA Section -->
            <div style="text-align: center; margin-bottom: 32px; padding: 24px; background-color: #eee9e3; border-radius: 8px;">
              <p style="color: #2f2724; margin: 0 0 16px 0; font-size: 16px;">Not sure where to start?</p>
              <a href="https://${process.env.REPLIT_DEV_DOMAIN || 'podiease.com'}/quiz" style="display: inline-block; background-color: #593f32; color: #ffffff; padding: 12px 32px; text-decoration: none; border-radius: 4px; font-weight: 600; margin-bottom: 8px;">Take Our Free Foot Health Quiz</a>
              <p style="color: #7f6355; font-size: 14px; margin: 8px 0 0 0;">Get a personalized 7-day program in under 2 minutes</p>
            </div>

            <!-- Footer -->
            <div style="text-align: center; padding-top: 24px; border-top: 1px solid #d3b495;">
              <p style="color: #7f6355; font-size: 14px; margin: 0 0 8px 0;">Expert care, delivered to your door</p>
              <p style="color: #7f6355; font-size: 12px; margin: 0 0 12px 0;">
                PodiEase - Australia's trusted podiatrist-led store for plantar fasciitis relief
              </p>
              <p style="color: #7f6355; font-size: 11px; margin: 0;">
                You're receiving this email because you subscribed at podiease.com
              </p>
            </div>

          </div>
        </body>
      </html>
    `;

    const result = await client.emails.send({
      from: fromEmail,
      to: data.email,
      subject: 'Welcome to PodiEase - Your Journey to Pain-Free Movement Starts Here 🦶',
      html,
    });

    console.log('Welcome email sent successfully:', result);
    return result;
  } catch (error) {
    console.error('Error sending welcome email:', error);
    throw error;
  }
}
