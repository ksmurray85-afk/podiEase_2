import type { Express } from "express";
import { createServer, type Server } from "http";
import { getProducts, createCheckout } from "./shopify";
import { db } from "./db";
import { 
  reviews, 
  newsletterSubscribers, 
  quizPrograms,
  quizQuestions,
  quizSessions,
  quizAnswers,
  insertReviewSchema, 
  insertNewsletterSubscriberSchema,
  insertQuizSessionSchema,
  insertQuizAnswerSchema
} from "@shared/schema";
import { eq, desc, sql, and } from "drizzle-orm";

export async function registerRoutes(app: Express): Promise<Server> {
  app.get("/api/products", async (req, res) => {
    try {
      const products = await getProducts();
      res.json(products);
    } catch (error) {
      console.error("Error fetching products:", error);
      res.status(500).json({ error: "Failed to fetch products" });
    }
  });

  app.post("/api/checkout", async (req, res) => {
    const SHOPIFY_DOMAIN = process.env.SHOPIFY_STORE_DOMAIN;
    const STOREFRONT_ACCESS_TOKEN = process.env.SHOPIFY_STOREFRONT_ACCESS_TOKEN;

    if (!SHOPIFY_DOMAIN || !STOREFRONT_ACCESS_TOKEN) {
      return res.status(501).json({ 
        error: "Checkout is not available in demo mode. Please configure Shopify credentials to enable checkout functionality.",
        isDemoMode: true
      });
    }

    try {
      const { lineItems } = req.body;
      
      if (!lineItems || !Array.isArray(lineItems)) {
        return res.status(400).json({ error: "Invalid line items" });
      }

      const checkout = await createCheckout(lineItems);
      res.json(checkout);
    } catch (error) {
      console.error("Error creating checkout:", error);
      const errorMessage = error instanceof Error ? error.message : "Failed to create checkout";
      res.status(500).json({ error: errorMessage });
    }
  });

  // Reviews endpoints
  app.get("/api/reviews", async (req, res) => {
    try {
      const productId = req.query.productId as string | undefined;
      
      let allReviews;
      if (productId) {
        allReviews = await db.select().from(reviews).where(eq(reviews.productId, productId)).orderBy(desc(reviews.createdAt));
      } else {
        allReviews = await db.select().from(reviews).orderBy(desc(reviews.createdAt));
      }
      
      res.json(allReviews);
    } catch (error) {
      console.error("Error fetching reviews:", error);
      res.status(500).json({ error: "Failed to fetch reviews" });
    }
  });

  app.post("/api/reviews", async (req, res) => {
    try {
      const validatedData = insertReviewSchema.parse(req.body);
      
      const [newReview] = await db.insert(reviews).values(validatedData).returning();
      
      res.status(201).json(newReview);
    } catch (error) {
      console.error("Error creating review:", error);
      res.status(400).json({ error: "Failed to create review" });
    }
  });

  app.patch("/api/reviews/:id/helpful", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      const [updated] = await db
        .update(reviews)
        .set({ helpful: sql`${reviews.helpful} + 1` })
        .where(eq(reviews.id, id))
        .returning();
      
      res.json(updated);
    } catch (error) {
      console.error("Error updating review:", error);
      res.status(500).json({ error: "Failed to update review" });
    }
  });

  // Newsletter subscription endpoints
  app.post("/api/newsletter/subscribe", async (req, res) => {
    try {
      const validatedData = insertNewsletterSubscriberSchema.parse(req.body);
      
      const existingSubscriber = await db
        .select()
        .from(newsletterSubscribers)
        .where(eq(newsletterSubscribers.email, validatedData.email))
        .limit(1);

      if (existingSubscriber.length > 0) {
        return res.status(409).json({ 
          error: "This email is already subscribed to our newsletter" 
        });
      }

      const [newSubscriber] = await db
        .insert(newsletterSubscribers)
        .values(validatedData)
        .returning();
      
      // Send welcome email to new subscriber
      try {
        const { sendWelcomeEmail } = await import("./email");
        
        await sendWelcomeEmail({
          email: newSubscriber.email,
          firstName: newSubscriber.firstName || undefined,
        });
      } catch (emailError) {
        console.error('Failed to send welcome email:', emailError);
        // Don't fail the request if email fails
      }
      
      res.status(201).json({ 
        message: "Successfully subscribed to newsletter",
        subscriber: newSubscriber 
      });
    } catch (error) {
      console.error("Error subscribing to newsletter:", error);
      res.status(400).json({ error: "Failed to subscribe to newsletter" });
    }
  });

  // Quiz endpoints
  
  // Seed quiz data (development only)
  app.post("/api/quiz/seed", async (req, res) => {
    // Security: Only allow seeding in development environment
    if (process.env.NODE_ENV === "production") {
      return res.status(403).json({ error: "Seed endpoint is disabled in production" });
    }
    
    try {
      // Check if already seeded
      const existingQuestions = await db.select().from(quizQuestions).limit(1);
      if (existingQuestions.length > 0) {
        return res.json({ message: "Quiz data already seeded" });
      }

      // Insert programs
      const programs = [
        {
          slug: "plantar-fasciitis-relief",
          title: "Plantar Fasciitis Relief Program",
          description: "A 7-day program specifically designed to relieve plantar fasciitis pain through targeted stretches, strengthening exercises, and recovery techniques.",
          targetConditions: ["plantar-fasciitis", "heel-pain", "arch-pain"],
          dayPlan: [
            { day: 1, title: "Foundation & Assessment", exercises: ["Toe curls", "Arch massage", "Gentle calf stretch"], tips: ["Start slowly", "Use ice after exercises", "Wear supportive footwear"], duration: "10-15 minutes" },
            { day: 2, title: "Flexibility Focus", exercises: ["Towel stretch", "Plantar fascia massage", "Toe spreading"], tips: ["Perform stretches in morning", "Use a tennis ball for massage", "Stay hydrated"], duration: "15-20 minutes" },
            { day: 3, title: "Strengthening Begins", exercises: ["Resistance band exercises", "Heel raises", "Marble pickup"], tips: ["Focus on form", "Increase reps gradually", "Rest between sets"], duration: "15-20 minutes" },
            { day: 4, title: "Balance & Stability", exercises: ["Single-leg balance", "Proprioception mat work", "Ankle circles"], tips: ["Use wall for support if needed", "Practice barefoot", "Focus on controlled movements"], duration: "15-20 minutes" },
            { day: 5, title: "Progressive Strengthening", exercises: ["Toe bean bag exercises", "Advanced calf raises", "Arch strengthening"], tips: ["Increase resistance", "Monitor pain levels", "Ice after session"], duration: "20-25 minutes" },
            { day: 6, title: "Mobility & Recovery", exercises: ["Dynamic stretching", "Foam rolling", "Active recovery walks"], tips: ["Focus on full range of motion", "Listen to your body", "Gentle movements only"], duration: "20-25 minutes" },
            { day: 7, title: "Integration & Maintenance", exercises: ["Complete routine review", "Goal setting", "Long-term strategy"], tips: ["Celebrate progress", "Plan ongoing routine", "Schedule podiatrist follow-up if needed"], duration: "25-30 minutes" }
          ],
          recommendedProducts: [],
          isActive: true,
        },
        {
          slug: "general-foot-health",
          title: "General Foot Health & Wellness Program",
          description: "A comprehensive 7-day program to improve overall foot health, strength, and mobility for active individuals.",
          targetConditions: ["general-wellness", "prevention", "active-lifestyle"],
          dayPlan: [
            { day: 1, title: "Baseline Assessment", exercises: ["Basic toe exercises", "Foot flexibility test", "Posture check"], tips: ["Take before photos", "Note any discomfort", "Establish baseline"], duration: "10-15 minutes" },
            { day: 2, title: "Flexibility Development", exercises: ["Toe spacer wear", "Ankle mobility", "Calf stretching"], tips: ["Warm up first", "Hold stretches 30 seconds", "Breathe deeply"], duration: "15 minutes" },
            { day: 3, title: "Strength Building", exercises: ["Resistance bands", "Toe curls", "Arch activation"], tips: ["Start with light resistance", "Focus on control", "Rest between exercises"], duration: "15-20 minutes" },
            { day: 4, title: "Balance & Coordination", exercises: ["Single-leg stands", "Proprioception drills", "Stability work"], tips: ["Use support if needed", "Challenge yourself gradually", "Practice daily"], duration: "15 minutes" },
            { day: 5, title: "Advanced Strength", exercises: ["Progressive resistance", "Complex movements", "Functional training"], tips: ["Increase difficulty", "Maintain proper form", "Track progress"], duration: "20 minutes" },
            { day: 6, title: "Active Recovery", exercises: ["Light mobility work", "Massage techniques", "Gentle movement"], tips: ["Listen to your body", "Focus on recovery", "Stay active gently"], duration: "15 minutes" },
            { day: 7, title: "Maintenance Plan", exercises: ["Routine consolidation", "Future planning", "Lifestyle integration"], tips: ["Create sustainable habits", "Set ongoing goals", "Celebrate improvements"], duration: "20 minutes" }
          ],
          recommendedProducts: [],
          isActive: true,
        }
      ];

      await db.insert(quizPrograms).values(programs);

      // Insert questions
      const questions = [
        {
          question: "What is your primary foot concern?",
          type: "single-choice",
          order: 1,
          choices: [
            { value: "plantar-fasciitis", label: "Plantar Fasciitis / Heel Pain", weight: { "plantar-fasciitis-relief": 10 } },
            { value: "general-pain", label: "General foot pain", weight: { "plantar-fasciitis-relief": 5, "general-foot-health": 5 } },
            { value: "prevention", label: "Prevention & wellness", weight: { "general-foot-health": 10 } },
            { value: "arch-pain", label: "Arch pain or flat feet", weight: { "plantar-fasciitis-relief": 8 } },
          ],
          programSlug: null,
          isActive: true,
        },
        {
          question: "How would you describe your pain level?",
          type: "single-choice",
          order: 2,
          choices: [
            { value: "severe", label: "Severe (can't walk comfortably)", weight: { "plantar-fasciitis-relief": 10 } },
            { value: "moderate", label: "Moderate (affects daily activities)", weight: { "plantar-fasciitis-relief": 7 } },
            { value: "mild", label: "Mild (occasional discomfort)", weight: { "general-foot-health": 5 } },
            { value: "none", label: "No pain (prevention focused)", weight: { "general-foot-health": 10 } },
          ],
          programSlug: null,
          isActive: true,
        },
        {
          question: "When is your pain worst?",
          type: "multi-choice",
          order: 3,
          choices: [
            { value: "morning", label: "First steps in the morning", weight: { "plantar-fasciitis-relief": 10 } },
            { value: "standing", label: "After standing for long periods", weight: { "plantar-fasciitis-relief": 7 } },
            { value: "walking", label: "During or after walking/running", weight: { "plantar-fasciitis-relief": 8 } },
            { value: "evening", label: "End of day", weight: { "general-foot-health": 5 } },
            { value: "no-pain", label: "I don't have pain", weight: { "general-foot-health": 10 } },
          ],
          programSlug: null,
          isActive: true,
        },
        {
          question: "How active are you currently?",
          type: "single-choice",
          order: 4,
          choices: [
            { value: "sedentary", label: "Mostly sedentary", weight: { "general-foot-health": 5 } },
            { value: "light", label: "Light activity (occasional walks)", weight: { "general-foot-health": 7 } },
            { value: "moderate", label: "Moderately active (regular exercise)", weight: { "general-foot-health": 10 } },
            { value: "very-active", label: "Very active (daily intense exercise)", weight: { "plantar-fasciitis-relief": 5 } },
          ],
          programSlug: null,
          isActive: true,
        },
        {
          question: "Have you tried any treatments before?",
          type: "multi-choice",
          order: 5,
          choices: [
            { value: "orthotics", label: "Orthotics or insoles", weight: {} },
            { value: "physical-therapy", label: "Physical therapy", weight: {} },
            { value: "stretching", label: "Stretching exercises", weight: {} },
            { value: "medication", label: "Pain medication", weight: {} },
            { value: "rest", label: "Rest and ice", weight: {} },
            { value: "none", label: "Nothing yet", weight: {} },
          ],
          programSlug: null,
          isActive: true,
        },
        {
          question: "What are your main goals?",
          type: "multi-choice",
          order: 6,
          choices: [
            { value: "pain-relief", label: "Reduce or eliminate pain", weight: { "plantar-fasciitis-relief": 10 } },
            { value: "mobility", label: "Improve mobility and flexibility", weight: { "general-foot-health": 8 } },
            { value: "strength", label: "Build foot strength", weight: { "general-foot-health": 9 } },
            { value: "prevention", label: "Prevent future problems", weight: { "general-foot-health": 10 } },
            { value: "performance", label: "Enhance athletic performance", weight: { "general-foot-health": 7 } },
          ],
          programSlug: null,
          isActive: true,
        },
      ];

      await db.insert(quizQuestions).values(questions);

      res.json({ message: "Quiz data seeded successfully", programsCount: programs.length, questionsCount: questions.length });
    } catch (error) {
      console.error("Error seeding quiz data:", error);
      res.status(500).json({ error: "Failed to seed quiz data" });
    }
  });
  
  // Get all active quiz questions
  app.get("/api/quiz/questions", async (req, res) => {
    try {
      const questions = await db
        .select()
        .from(quizQuestions)
        .where(eq(quizQuestions.isActive, true))
        .orderBy(quizQuestions.order);
      
      res.json(questions);
    } catch (error) {
      console.error("Error fetching quiz questions:", error);
      res.status(500).json({ error: "Failed to fetch quiz questions" });
    }
  });

  // Get quiz program by ID (supports both numeric IDs and slugs for backward compatibility)
  app.get("/api/quiz/programs/:idOrSlug", async (req, res) => {
    try {
      const { idOrSlug } = req.params;
      
      // Try to parse as integer ID first
      const numericId = parseInt(idOrSlug);
      let program;
      
      if (!isNaN(numericId)) {
        // Fetch by ID
        [program] = await db
          .select()
          .from(quizPrograms)
          .where(and(
            eq(quizPrograms.id, numericId),
            eq(quizPrograms.isActive, true)
          ))
          .limit(1);
      } else {
        // Fetch by slug (for backward compatibility)
        [program] = await db
          .select()
          .from(quizPrograms)
          .where(and(
            eq(quizPrograms.slug, idOrSlug),
            eq(quizPrograms.isActive, true)
          ))
          .limit(1);
      }
      
      if (!program) {
        return res.status(404).json({ error: "Program not found" });
      }
      
      res.json(program);
    } catch (error) {
      console.error("Error fetching quiz program:", error);
      res.status(500).json({ error: "Failed to fetch quiz program" });
    }
  });

  // Create a new quiz session
  app.post("/api/quiz/sessions", async (req, res) => {
    try {
      const validatedData = insertQuizSessionSchema.parse(req.body);
      
      // Check if email is already subscribed to newsletter
      let subscriberId = null;
      if (validatedData.newsletterOptIn) {
        const existingSubscriber = await db
          .select()
          .from(newsletterSubscribers)
          .where(eq(newsletterSubscribers.email, validatedData.email))
          .limit(1);

        if (existingSubscriber.length > 0) {
          subscriberId = existingSubscriber[0].id;
        } else {
          // Create new newsletter subscriber
          const [newSubscriber] = await db
            .insert(newsletterSubscribers)
            .values({
              email: validatedData.email,
              firstName: validatedData.firstName || null,
              isActive: true,
            })
            .returning();
          subscriberId = newSubscriber.id;
        }
      }

      const [newSession] = await db
        .insert(quizSessions)
        .values({
          ...validatedData,
          subscriberId,
        })
        .returning();
      
      res.status(201).json(newSession);
    } catch (error) {
      console.error("Error creating quiz session:", error);
      res.status(400).json({ error: "Failed to create quiz session" });
    }
  });

  // Update quiz session with answers and result
  app.patch("/api/quiz/sessions/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const { answers } = req.body;

      if (!answers || !Array.isArray(answers) || answers.length === 0) {
        return res.status(400).json({ error: "Answers are required" });
      }

      // Delete existing answers for this session to prevent duplicates on retry
      await db.delete(quizAnswers).where(eq(quizAnswers.sessionId, id));

      // Save new answers
      for (const answer of answers) {
        const validatedAnswer = insertQuizAnswerSchema.parse({
          sessionId: id,
          questionId: answer.questionId,
          value: answer.value,
        });
        
        await db.insert(quizAnswers).values(validatedAnswer);
      }

      // Server-side program calculation (don't trust client)
      const questions = await db.select().from(quizQuestions);
      const programScores: Record<string, number> = {};

      for (const answer of answers) {
        const question = questions.find((q) => q.id === answer.questionId);
        if (!question) continue;

        // Parse answer value - handle both single-choice strings and JSON-encoded multi-choice arrays
        let answerValue: string | string[];
        if (typeof answer.value === 'string') {
          try {
            // Try to parse as JSON (for multi-choice arrays stored as JSON strings)
            answerValue = JSON.parse(answer.value);
          } catch {
            // If parsing fails, it's a single-choice string value
            answerValue = answer.value;
          }
        } else {
          answerValue = answer.value;
        }

        const selectedChoices = Array.isArray(answerValue) ? answerValue : [answerValue];

        selectedChoices.forEach((value: string) => {
          const choices = question.choices as any[] || [];
          const choice = choices.find((c: any) => c.value === value);
          if (choice?.weight && typeof choice.weight === 'object') {
            Object.entries(choice.weight).forEach(([program, score]) => {
              programScores[program] = (programScores[program] || 0) + (score as number);
            });
          }
        });
      }

      // Get highest scoring program slug, fallback to general-foot-health if no scores
      const recommendedProgramSlug = Object.entries(programScores)
        .sort(([, a], [, b]) => b - a)[0]?.[0] || "general-foot-health";

      // Look up the program by slug to get its integer ID
      const [program] = await db
        .select()
        .from(quizPrograms)
        .where(eq(quizPrograms.slug, recommendedProgramSlug))
        .limit(1);

      if (!program) {
        return res.status(500).json({ error: "Recommended program not found in database" });
      }

      // Update session with server-calculated recommendation (using program ID as integer)
      const [updatedSession] = await db
        .update(quizSessions)
        .set({
          resultProgramId: program.id,
          completedAt: new Date(),
        })
        .where(eq(quizSessions.id, id))
        .returning();
      
      // Send quiz result email with 7-day plan
      try {
        const { sendQuizResultEmail } = await import("./email");
        
        await sendQuizResultEmail({
          firstName: updatedSession.firstName || 'Friend',
          email: updatedSession.email,
          programTitle: program.title,
          programDescription: program.description,
          dayPlan: program.dayPlan as any,
        });
      } catch (emailError) {
        console.error('Failed to send quiz result email:', emailError);
        // Don't fail the request if email fails
      }
      
      res.json(updatedSession);
    } catch (error) {
      console.error("Error updating quiz session:", error);
      res.status(400).json({ error: "Failed to update quiz session" });
    }
  });

  // Get quiz session with answers
  app.get("/api/quiz/sessions/:id", async (req, res) => {
    try {
      const { id } = req.params;
      
      const [session] = await db
        .select()
        .from(quizSessions)
        .where(eq(quizSessions.id, id))
        .limit(1);
      
      if (!session) {
        return res.status(404).json({ error: "Session not found" });
      }

      const answers = await db
        .select()
        .from(quizAnswers)
        .where(eq(quizAnswers.sessionId, id));
      
      res.json({ ...session, answers });
    } catch (error) {
      console.error("Error fetching quiz session:", error);
      res.status(500).json({ error: "Failed to fetch quiz session" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
