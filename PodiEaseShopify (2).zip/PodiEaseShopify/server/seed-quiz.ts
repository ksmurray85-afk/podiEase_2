import { db } from "./db";
import { quizPrograms, quizQuestions } from "@shared/schema";

async function seedQuiz() {
  console.log("🌱 Seeding quiz data...");

  try {
    // Insert quiz programs (7-day foot health programs)
    const programs = [
      {
        slug: "plantar-fasciitis-relief",
        title: "Plantar Fasciitis Relief Program",
        description: "A 7-day program specifically designed to relieve plantar fasciitis pain through targeted stretches, strengthening exercises, and recovery techniques.",
        targetConditions: ["plantar-fasciitis", "heel-pain", "arch-pain"],
        dayPlan: [
          {
            day: 1,
            title: "Foundation & Assessment",
            exercises: ["Toe curls", "Arch massage", "Gentle calf stretch"],
            tips: ["Start slowly", "Use ice after exercises", "Wear supportive footwear"],
            duration: "10-15 minutes"
          },
          {
            day: 2,
            title: "Flexibility Focus",
            exercises: ["Towel stretch", "Plantar fascia massage", "Toe spreading"],
            tips: ["Perform stretches in morning", "Use a tennis ball for massage", "Stay hydrated"],
            duration: "15-20 minutes"
          },
          {
            day: 3,
            title: "Strengthening Begins",
            exercises: ["Resistance band exercises", "Heel raises", "Marble pickup"],
            tips: ["Focus on form", "Increase reps gradually", "Rest between sets"],
            duration: "15-20 minutes"
          },
          {
            day: 4,
            title: "Balance & Stability",
            exercises: ["Single-leg balance", "Proprioception mat work", "Ankle circles"],
            tips: ["Use wall for support if needed", "Practice barefoot", "Focus on controlled movements"],
            duration: "15-20 minutes"
          },
          {
            day: 5,
            title: "Progressive Strengthening",
            exercises: ["Toe bean bag exercises", "Advanced calf raises", "Arch strengthening"],
            tips: ["Increase resistance", "Monitor pain levels", "Ice after session"],
            duration: "20-25 minutes"
          },
          {
            day: 6,
            title: "Mobility & Recovery",
            exercises: ["Dynamic stretching", "Foam rolling", "Active recovery walks"],
            tips: ["Focus on full range of motion", "Listen to your body", "Gentle movements only"],
            duration: "20-25 minutes"
          },
          {
            day: 7,
            title: "Integration & Maintenance",
            exercises: ["Complete routine review", "Goal setting", "Long-term strategy"],
            tips: ["Celebrate progress", "Plan ongoing routine", "Schedule podiatrist follow-up if needed"],
            duration: "25-30 minutes"
          }
        ],
        recommendedProducts: [], // Will be populated with Shopify product IDs
        isActive: true,
      },
      {
        slug: "general-foot-health",
        title: "General Foot Health & Wellness Program",
        description: "A comprehensive 7-day program to improve overall foot health, strength, and mobility for active individuals.",
        targetConditions: ["general-wellness", "prevention", "active-lifestyle"],
        dayPlan: [
          {
            day: 1,
            title: "Baseline Assessment",
            exercises: ["Basic toe exercises", "Foot flexibility test", "Posture check"],
            tips: ["Take before photos", "Note any discomfort", "Establish baseline"],
            duration: "10-15 minutes"
          },
          {
            day: 2,
            title: "Flexibility Development",
            exercises: ["Toe spacer wear", "Ankle mobility", "Calf stretching"],
            tips: ["Warm up first", "Hold stretches 30 seconds", "Breathe deeply"],
            duration: "15 minutes"
          },
          {
            day: 3,
            title: "Strength Building",
            exercises: ["Resistance bands", "Toe curls", "Arch activation"],
            tips: ["Start with light resistance", "Focus on control", "Rest between exercises"],
            duration: "15-20 minutes"
          },
          {
            day: 4,
            title: "Balance & Coordination",
            exercises: ["Single-leg stands", "Proprioception drills", "Stability work"],
            tips: ["Use support if needed", "Challenge yourself gradually", "Practice daily"],
            duration: "15 minutes"
          },
          {
            day: 5,
            title: "Advanced Strength",
            exercises: ["Progressive resistance", "Complex movements", "Functional training"],
            tips: ["Increase difficulty", "Maintain proper form", "Track progress"],
            duration: "20 minutes"
          },
          {
            day: 6,
            title: "Active Recovery",
            exercises: ["Light mobility work", "Massage techniques", "Gentle movement"],
            tips: ["Listen to your body", "Focus on recovery", "Stay active gently"],
            duration: "15 minutes"
          },
          {
            day: 7,
            title: "Maintenance Plan",
            exercises: ["Routine consolidation", "Future planning", "Lifestyle integration"],
            tips: ["Create sustainable habits", "Set ongoing goals", "Celebrate improvements"],
            duration: "20 minutes"
          }
        ],
        recommendedProducts: [],
        isActive: true,
      }
    ];

    console.log("Inserting programs...");
    const insertedPrograms = await db.insert(quizPrograms).values(programs).returning();
    console.log(`✅ Inserted ${insertedPrograms.length} programs`);

    // Insert quiz questions
    const questions = [
      {
        question: "What is your primary foot concern?",
        type: "single-choice",
        order: 1,
        choices: [
          { value: "plantar-fasciitis", label: "Plantar Fasciitis / Heel Pain", weight: { "plantar-fasciitis-relief": 10 } },
          { value: "general-pain", label: "General foot pain", weight: { "plantar-fasciitis-relief": 5, "general-foot-health": 5 } },
          { value: "prevention", label: "Prevention & wellness", weight: { "general-foot-health": 10 } },
          { value: "arch-pain", label: "Arch pain or flat feet", weight: { "plantar-fasciitis-relief": 8 } },
        ],
        programSlug: null,
        isActive: true,
      },
      {
        question: "How would you describe your pain level?",
        type: "single-choice",
        order: 2,
        choices: [
          { value: "severe", label: "Severe (can't walk comfortably)", weight: { "plantar-fasciitis-relief": 10 } },
          { value: "moderate", label: "Moderate (affects daily activities)", weight: { "plantar-fasciitis-relief": 7 } },
          { value: "mild", label: "Mild (occasional discomfort)", weight: { "general-foot-health": 5 } },
          { value: "none", label: "No pain (prevention focused)", weight: { "general-foot-health": 10 } },
        ],
        programSlug: null,
        isActive: true,
      },
      {
        question: "When is your pain worst?",
        type: "multi-choice",
        order: 3,
        choices: [
          { value: "morning", label: "First steps in the morning", weight: { "plantar-fasciitis-relief": 10 } },
          { value: "standing", label: "After standing for long periods", weight: { "plantar-fasciitis-relief": 7 } },
          { value: "walking", label: "During or after walking/running", weight: { "plantar-fasciitis-relief": 8 } },
          { value: "evening", label: "End of day", weight: { "general-foot-health": 5 } },
          { value: "no-pain", label: "I don't have pain", weight: { "general-foot-health": 10 } },
        ],
        programSlug: null,
        isActive: true,
      },
      {
        question: "How active are you currently?",
        type: "single-choice",
        order: 4,
        choices: [
          { value: "sedentary", label: "Mostly sedentary", weight: { "general-foot-health": 5 } },
          { value: "light", label: "Light activity (occasional walks)", weight: { "general-foot-health": 7 } },
          { value: "moderate", label: "Moderately active (regular exercise)", weight: { "general-foot-health": 10 } },
          { value: "very-active", label: "Very active (daily intense exercise)", weight: { "plantar-fasciitis-relief": 5 } },
        ],
        programSlug: null,
        isActive: true,
      },
      {
        question: "Have you tried any treatments before?",
        type: "multi-choice",
        order: 5,
        choices: [
          { value: "orthotics", label: "Orthotics or insoles", weight: {} },
          { value: "physical-therapy", label: "Physical therapy", weight: {} },
          { value: "stretching", label: "Stretching exercises", weight: {} },
          { value: "medication", label: "Pain medication", weight: {} },
          { value: "rest", label: "Rest and ice", weight: {} },
          { value: "none", label: "Nothing yet", weight: {} },
        ],
        programSlug: null,
        isActive: true,
      },
      {
        question: "What are your main goals?",
        type: "multi-choice",
        order: 6,
        choices: [
          { value: "pain-relief", label: "Reduce or eliminate pain", weight: { "plantar-fasciitis-relief": 10 } },
          { value: "mobility", label: "Improve mobility and flexibility", weight: { "general-foot-health": 8 } },
          { value: "strength", label: "Build foot strength", weight: { "general-foot-health": 9 } },
          { value: "prevention", label: "Prevent future problems", weight: { "general-foot-health": 10 } },
          { value: "performance", label: "Enhance athletic performance", weight: { "general-foot-health": 7 } },
        ],
        programSlug: null,
        isActive: true,
      },
    ];

    console.log("Inserting questions...");
    const insertedQuestions = await db.insert(quizQuestions).values(questions).returning();
    console.log(`✅ Inserted ${insertedQuestions.length} questions`);

    console.log("✅ Quiz seeding complete!");
    process.exit(0);
  } catch (error) {
    console.error("❌ Error seeding quiz data:", error);
    process.exit(1);
  }
}

seedQuiz();
