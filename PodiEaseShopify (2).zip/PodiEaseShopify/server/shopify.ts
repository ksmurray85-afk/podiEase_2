import { createStorefrontApiClient } from '@shopify/storefront-api-client';
import { type Product } from "@shared/schema";

const SHOPIFY_DOMAIN = process.env.SHOPIFY_STORE_DOMAIN;
const STOREFRONT_ACCESS_TOKEN = process.env.SHOPIFY_STOREFRONT_ACCESS_TOKEN;

if (!SHOPIFY_DOMAIN || !STOREFRONT_ACCESS_TOKEN) {
  console.warn("Shopify credentials not configured. Using mock data.");
}

let shopifyClient: ReturnType<typeof createStorefrontApiClient> | null = null;

if (SHOPIFY_DOMAIN && STOREFRONT_ACCESS_TOKEN) {
  // Remove protocol if present - Shopify client adds https:// automatically
  const cleanDomain = SHOPIFY_DOMAIN.replace(/^https?:\/\//, '');
  
  shopifyClient = createStorefrontApiClient({
    storeDomain: cleanDomain,
    apiVersion: '2025-01',
    publicAccessToken: STOREFRONT_ACCESS_TOKEN,
  });
  
  console.log(`Shopify client initialized for domain: ${cleanDomain}`);
}

interface ShopifyProduct {
  id: string;
  title: string;
  description: string;
  handle: string;
  images: {
    edges: Array<{
      node: {
        url: string;
      };
    }>;
  };
  variants: {
    edges: Array<{
      node: {
        id: string;
        priceV2: {
          amount: string;
        };
        compareAtPriceV2: {
          amount: string;
        } | null;
        availableForSale: boolean;
      };
    }>;
  };
  tags: string[];
}

export async function getProducts(): Promise<Product[]> {
  const query = `
    query getProducts($first: Int!) {
      products(first: $first) {
        edges {
          node {
            id
            title
            description
            handle
            tags
            images(first: 5) {
              edges {
                node {
                  url
                }
              }
            }
            variants(first: 1) {
              edges {
                node {
                  id
                  priceV2 {
                    amount
                  }
                  compareAtPriceV2 {
                    amount
                  }
                  availableForSale
                }
              }
            }
          }
        }
      }
    }
  `;

  if (!shopifyClient) {
    console.log("Shopify not configured, using mock products");
    return getMockProducts();
  }

  try {
    const { data, errors } = await shopifyClient.request(query, {
      variables: { first: 20 },
    });

    if (errors) {
      console.error("Shopify GraphQL errors:", errors);
      return getMockProducts();
    }
    
    return data.products.edges.map((edge: { node: ShopifyProduct }) => {
      const product = edge.node;
      const variant = product.variants.edges[0]?.node;
      const images = product.images.edges.map((img) => img.node.url);

      return {
        id: product.id,
        title: product.title,
        description: product.description || "",
        price: parseFloat(variant?.priceV2.amount || "0").toFixed(2),
        compareAtPrice: variant?.compareAtPriceV2?.amount ? parseFloat(variant.compareAtPriceV2.amount).toFixed(2) : undefined,
        image: images[0] || "",
        images: images,
        available: variant?.availableForSale || false,
        handle: product.handle,
        tags: product.tags,
        isPodiatristPick: product.tags?.includes("podiatrist-pick") || false,
        variantId: variant?.id,
      };
    });
  } catch (error) {
    console.error("Error fetching Shopify products:", error);
    return getMockProducts();
  }
}

export async function createCheckout(lineItems: Array<{ variantId: string; quantity: number }>) {
  if (!shopifyClient) {
    throw new Error("Shopify checkout is not available. Please configure Shopify credentials.");
  }

  if (!lineItems || lineItems.length === 0) {
    throw new Error("Cannot create checkout with empty cart");
  }

  const mutation = `
    mutation checkoutCreate($input: CheckoutCreateInput!) {
      checkoutCreate(input: $input) {
        checkout {
          id
          webUrl
          lineItems(first: 10) {
            edges {
              node {
                id
                title
                quantity
              }
            }
          }
          totalPriceV2 {
            amount
          }
        }
        checkoutUserErrors {
          field
          message
        }
      }
    }
  `;

  try {
    const { data, errors } = await shopifyClient.request(mutation, {
      variables: {
        input: {
          lineItems: lineItems.map((item) => ({
            variantId: item.variantId,
            quantity: item.quantity,
          })),
        },
      },
    });

    if (errors) {
      throw new Error(`Shopify GraphQL errors: ${JSON.stringify(errors)}`);
    }

    if (data.checkoutCreate.checkoutUserErrors.length > 0) {
      const userErrors = data.checkoutCreate.checkoutUserErrors;
      throw new Error(`Checkout error: ${userErrors.map((e: any) => e.message).join(", ")}`);
    }

    const checkout = data.checkoutCreate.checkout;
    
    if (!checkout || !checkout.webUrl) {
      throw new Error("Invalid checkout response from Shopify");
    }

    return {
      id: checkout.id,
      webUrl: checkout.webUrl,
      lineItems: checkout.lineItems.edges.map((edge: any) => edge.node),
      totalPrice: checkout.totalPriceV2.amount,
    };
  } catch (error) {
    console.error("Error creating Shopify checkout:", error);
    throw error;
  }
}

function getMockProducts(): Product[] {
  return [
    {
      id: "mock-product-1",
      title: "Premium Orthotic Insoles",
      description: "Medical-grade arch support insoles designed to reduce plantar fascia strain and provide all-day comfort",
      price: "79.95",
      compareAtPrice: "99.95",
      image: "https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?w=800&h=800&fit=crop",
      images: ["https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?w=800&h=800&fit=crop"],
      available: true,
      handle: "premium-orthotic-insoles",
      tags: ["orthotic", "insoles", "arch support", "podiatrist-pick"],
      isPodiatristPick: true,
      variantId: "mock-variant-1",
    },
    {
      id: "mock-product-2",
      title: "Gel Heel Cushions",
      description: "Shock-absorbing gel pads that reduce impact and provide immediate heel pain relief",
      price: "34.95",
      image: "https://images.unsplash.com/photo-1603487742131-4160ec999306?w=800&h=800&fit=crop",
      images: ["https://images.unsplash.com/photo-1603487742131-4160ec999306?w=800&h=800&fit=crop"],
      available: true,
      handle: "gel-heel-cushions",
      tags: ["heel", "cushion", "gel", "podiatrist-pick"],
      isPodiatristPick: true,
      variantId: "mock-variant-2",
    },
    {
      id: "mock-product-3",
      title: "Night Splint Boot",
      description: "Maintain proper foot position during sleep to promote healing and reduce morning pain",
      price: "89.95",
      image: "https://images.unsplash.com/photo-1512201078372-9c6b2a0d528a?w=800&h=800&fit=crop",
      images: ["https://images.unsplash.com/photo-1512201078372-9c6b2a0d528a?w=800&h=800&fit=crop"],
      available: true,
      handle: "night-splint-boot",
      tags: ["night splint", "recovery", "podiatrist-pick"],
      isPodiatristPick: true,
      variantId: "mock-variant-3",
    },
    {
      id: "mock-product-4",
      title: "Compression Foot Sleeves",
      description: "Targeted compression therapy to reduce inflammation and improve circulation",
      price: "44.95",
      image: "https://images.unsplash.com/photo-1556906781-9a412961c28c?w=800&h=800&fit=crop",
      images: ["https://images.unsplash.com/photo-1556906781-9a412961c28c?w=800&h=800&fit=crop"],
      available: true,
      handle: "compression-foot-sleeves",
      tags: ["compression", "sleeves"],
      isPodiatristPick: false,
      variantId: "mock-variant-4",
    },
    {
      id: "mock-product-5",
      title: "Massage Ball Set",
      description: "Therapeutic massage balls for targeted fascia release and pain relief",
      price: "29.95",
      image: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=800&h=800&fit=crop",
      images: ["https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=800&h=800&fit=crop"],
      available: true,
      handle: "massage-ball-set",
      tags: ["massage", "therapy"],
      isPodiatristPick: false,
      variantId: "mock-variant-5",
    },
    {
      id: "mock-product-6",
      title: "Arch Support Straps",
      description: "Adjustable support straps that provide customizable arch lift and stability",
      price: "39.95",
      image: "https://images.unsplash.com/photo-1460353581641-37baddab0fa2?w=800&h=800&fit=crop",
      images: ["https://images.unsplash.com/photo-1460353581641-37baddab0fa2?w=800&h=800&fit=crop"],
      available: true,
      handle: "arch-support-straps",
      tags: ["arch support", "straps"],
      isPodiatristPick: false,
      variantId: "mock-variant-6",
    },
  ];
}
