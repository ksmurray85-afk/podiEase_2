import { z } from "zod";
import { pgTable, serial, varchar, text, integer, timestamp, boolean, uuid, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { sql } from "drizzle-orm";

// Database Tables

// Reviews table
export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  productId: varchar("product_id", { length: 255 }).notNull(),
  productTitle: varchar("product_title", { length: 255 }).notNull(),
  customerName: varchar("customer_name", { length: 255 }).notNull(),
  customerEmail: varchar("customer_email", { length: 255 }).notNull(),
  rating: integer("rating").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  comment: text("comment").notNull(),
  verifiedPurchase: boolean("verified_purchase").default(false).notNull(),
  beforePhoto: varchar("before_photo", { length: 500 }),
  afterPhoto: varchar("after_photo", { length: 500 }),
  storyText: text("story_text"),
  helpful: integer("helpful").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertReviewSchema = createInsertSchema(reviews).omit({ id: true, createdAt: true, helpful: true });
export const selectReviewSchema = createSelectSchema(reviews);
export type InsertReview = z.infer<typeof insertReviewSchema>;
export type Review = z.infer<typeof selectReviewSchema>;

// Newsletter subscriptions table
export const newsletterSubscribers = pgTable("newsletter_subscribers", {
  id: serial("id").primaryKey(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  firstName: varchar("first_name", { length: 255 }),
  lastName: varchar("last_name", { length: 255 }),
  subscribedAt: timestamp("subscribed_at").defaultNow().notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  confirmationToken: varchar("confirmation_token", { length: 255 }),
  confirmedAt: timestamp("confirmed_at"),
});

export const insertNewsletterSubscriberSchema = createInsertSchema(newsletterSubscribers).omit({ 
  id: true, 
  subscribedAt: true, 
  confirmedAt: true 
});
export const selectNewsletterSubscriberSchema = createSelectSchema(newsletterSubscribers);
export type InsertNewsletterSubscriber = z.infer<typeof insertNewsletterSubscriberSchema>;
export type NewsletterSubscriber = z.infer<typeof selectNewsletterSubscriberSchema>;

// Product schema for Shopify integration
export const productSchema = z.object({
  id: z.string(),
  title: z.string(),
  description: z.string(),
  price: z.string(),
  compareAtPrice: z.string().optional(),
  image: z.string(),
  images: z.array(z.string()),
  available: z.boolean(),
  handle: z.string(),
  tags: z.array(z.string()).optional(),
  isPodiatristPick: z.boolean().optional(),
  variantId: z.string(),
});

export type Product = z.infer<typeof productSchema>;

// Cart item schema
export const cartItemSchema = z.object({
  id: z.string(),
  productId: z.string(),
  variantId: z.string(),
  title: z.string(),
  price: z.string(),
  quantity: z.number(),
  image: z.string(),
});

export type CartItem = z.infer<typeof cartItemSchema>;

// Cart schema
export const cartSchema = z.object({
  items: z.array(cartItemSchema),
  total: z.string(),
  itemCount: z.number(),
});

export type Cart = z.infer<typeof cartSchema>;

// Shopify checkout schema
export const checkoutSchema = z.object({
  id: z.string(),
  webUrl: z.string(),
  lineItems: z.array(z.any()),
  totalPrice: z.string(),
});

export type Checkout = z.infer<typeof checkoutSchema>;

// Quiz Programs table - stores 7-day personalized programs
export const quizPrograms = pgTable("quiz_programs", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description").notNull(),
  targetConditions: text("target_conditions").array(),
  dayPlan: jsonb("day_plan").notNull(), // Array of 7 day objects with title, exercises, tips
  recommendedProducts: text("recommended_products").array(), // Shopify product IDs
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertQuizProgramSchema = createInsertSchema(quizPrograms).omit({ id: true, createdAt: true });
export const selectQuizProgramSchema = createSelectSchema(quizPrograms);
export type InsertQuizProgram = z.infer<typeof insertQuizProgramSchema>;
export type QuizProgram = z.infer<typeof selectQuizProgramSchema>;

// Quiz Questions table - stores questions and answer choices
export const quizQuestions = pgTable("quiz_questions", {
  id: serial("id").primaryKey(),
  question: text("question").notNull(),
  type: varchar("type", { length: 50 }).notNull(), // 'single-choice', 'multi-choice', 'text'
  order: integer("order").notNull(),
  choices: jsonb("choices"), // Array of choice objects { value, label, weight }
  programSlug: varchar("program_slug", { length: 255 }), // Optional: associate with specific program
  isActive: boolean("is_active").default(true).notNull(),
});

export const insertQuizQuestionSchema = createInsertSchema(quizQuestions).omit({ id: true });
export const selectQuizQuestionSchema = createSelectSchema(quizQuestions);
export type InsertQuizQuestion = z.infer<typeof insertQuizQuestionSchema>;
export type QuizQuestion = z.infer<typeof selectQuizQuestionSchema>;

// Quiz Sessions table - stores user quiz attempts
export const quizSessions = pgTable("quiz_sessions", {
  id: varchar("id", { length: 36 }).primaryKey().$defaultFn(() => crypto.randomUUID()),
  email: varchar("email", { length: 255 }).notNull(),
  firstName: varchar("first_name", { length: 255 }),
  subscriberId: integer("subscriber_id").references(() => newsletterSubscribers.id),
  startedAt: timestamp("started_at").defaultNow().notNull(),
  completedAt: timestamp("completed_at"),
  resultProgramId: integer("result_program_id").references(() => quizPrograms.id),
  leadSource: varchar("lead_source", { length: 100 }).default('quiz').notNull(),
  newsletterOptIn: boolean("newsletter_opt_in").default(false).notNull(),
});

export const insertQuizSessionSchema = createInsertSchema(quizSessions).omit({ id: true, startedAt: true });
export const selectQuizSessionSchema = createSelectSchema(quizSessions);
export type InsertQuizSession = z.infer<typeof insertQuizSessionSchema>;
export type QuizSession = z.infer<typeof selectQuizSessionSchema>;

// Quiz Answers table - stores individual answers
export const quizAnswers = pgTable("quiz_answers", {
  id: serial("id").primaryKey(),
  sessionId: varchar("session_id", { length: 36 }).notNull().references(() => quizSessions.id),
  questionId: integer("question_id").notNull().references(() => quizQuestions.id),
  value: jsonb("value").notNull(), // Can store string, array of strings, or object
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertQuizAnswerSchema = createInsertSchema(quizAnswers).omit({ id: true, createdAt: true });
export const selectQuizAnswerSchema = createSelectSchema(quizAnswers);
export type InsertQuizAnswer = z.infer<typeof insertQuizAnswerSchema>;
export type QuizAnswer = z.infer<typeof selectQuizAnswerSchema>;
